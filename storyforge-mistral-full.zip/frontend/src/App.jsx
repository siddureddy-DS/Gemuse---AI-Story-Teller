import React, { useState, useEffect, useContext, createContext } from 'react'
import { Routes, Route, Link, Navigate, useNavigate, useParams } from 'react-router-dom'
import axios from 'axios'

const Api = axios.create({
  baseURL: '/api',
})

const AppContext = createContext(null)

function useApp() {
  return useContext(AppContext)
}

const initialDemoStory = {
  id: 'demo-1',
  title: 'Night Shift (Demo)',
  genre: 'Thriller',
  length: 'Short',
  scenes: [
    {
      id: 1,
      title: 'Alone in the Ward',
      location: 'Hospital night ward',
      characters: ['MAYA'],
      mood: 'Tense',
      text: 'Maya walks through the dimly lit hospital corridor, the buzz of old lights following her.'
    }
  ],
  world: null,
  cost: null,
  screenplay: ''
}

function AppProvider({ children }) {
  const [user, setUser] = useState(null)
  const [stories, setStories] = useState([initialDemoStory])

  useEffect(() => {
    const saved = localStorage.getItem('sf-mistral-state')
    if (saved) {
      try {
        const parsed = JSON.parse(saved)
        setUser(parsed.user || null)
        setStories(parsed.stories?.length ? parsed.stories : [initialDemoStory])
      } catch (e) {
        console.error('Failed to load state', e)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('sf-mistral-state', JSON.stringify({ user, stories }))
  }, [user, stories])

  const value = { user, setUser, stories, setStories }
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

function PrivateRoute({ children }) {
  const { user } = useApp()
  if (!user) return <Navigate to="/login" replace />
  return children
}

function Layout({ children }) {
  const { user, setUser } = useApp()
  const navigate = useNavigate()
  const logout = () => {
    setUser(null)
    navigate('/login')
  }
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to={user ? '/dashboard' : '/'} className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 rounded-xl bg-indigo-500/80 items-center justify-center text-lg font-bold">SF</span>
            <div>
              <div className="font-semibold tracking-tight">StoryForge Pro</div>
              <div className="text-xs text-slate-400">Mistral-powered story engine</div>
            </div>
          </Link>
          <nav className="flex items-center gap-4 text-sm">
            {user && (
              <>
                <Link to="/dashboard" className="hover:text-indigo-300">Dashboard</Link>
                <Link to="/world" className="hover:text-indigo-300">World</Link>
                <Link to="/cost" className="hover:text-indigo-300">Cost</Link>
                <Link to="/screenplay" className="hover:text-indigo-300">Screenplay</Link>
                <Link to="/download" className="hover:text-indigo-300">Download</Link>
                <Link to="/settings" className="hover:text-indigo-300">Settings</Link>
              </>
            )}
            {user ? (
              <button
                onClick={logout}
                className="text-xs px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-600"
              >
                Logout
              </button>
            ) : (
              <>
                <Link to="/login" className="hover:text-indigo-300">Login</Link>
                <Link
                  to="/signup"
                  className="px-3 py-1 rounded-full bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
                >
                  Sign up
                </Link>
              </>
            )}
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-6">{children}</div>
      </main>
      <footer className="border-t border-slate-800 text-xs text-slate-500 py-3 text-center">
        StoryForge Pro – Mistral Edition • Local demo app
      </footer>
    </div>
  )
}

function Landing() {
  const { user } = useApp()
  const navigate = useNavigate()
  useEffect(() => {
    if (user) navigate('/dashboard')
  }, [user, navigate])
  return (
    <div className="flex flex-col items-center justify-center py-20 gap-6">
      <h1 className="text-4xl font-bold tracking-tight text-center">
        Turn rough ideas into cinematic stories
      </h1>
      <p className="max-w-xl text-center text-slate-300">
        StoryForge Pro uses the Mistral LLM to generate stories scene-by-scene, enhance your writing,
        build worlds, estimate production cost, and export screenplay-style drafts.
      </p>
      <div className="flex gap-3">
        <Link
          to="/signup"
          className="px-6 py-2 rounded-full bg-indigo-500 hover:bg-indigo-400 text-sm font-semibold"
        >
          Get started
        </Link>
        <Link
          to="/login"
          className="px-6 py-2 rounded-full border border-slate-700 hover:border-slate-500 text-sm"
        >
          I already have an account
        </Link>
      </div>
    </div>
  )
}

function Login() {
  const { user, setUser } = useApp()
  const navigate = useNavigate()
  const [email, setEmail] = useState('demo@example.com')
  const [password, setPassword] = useState('demo123')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (user) navigate('/dashboard')
  }, [user, navigate])

  const onSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await Api.post('/auth/login', { email, password })
      setUser(res.data.user)
      navigate('/dashboard')
    } catch (err) {
      console.error(err)
      setError('Login failed. For quick demo, sign up first.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto mt-10 bg-slate-900/60 border border-slate-700 rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-4">Login</h2>
      <form onSubmit={onSubmit} className="space-y-4 text-sm">
        <div>
          <label className="block mb-1 text-slate-300">Email</label>
          <input
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="block mb-1 text-slate-300">Password</label>
          <input
            type="password"
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-sm font-semibold"
        >
          {loading ? 'Logging in…' : 'Login'}
        </button>
      </form>
    </div>
  )
}

function Signup() {
  const { user, setUser } = useApp()
  const navigate = useNavigate()
  const [name, setName] = useState('Demo User')
  const [email, setEmail] = useState('demo@example.com')
  const [password, setPassword] = useState('demo123')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    if (user) navigate('/dashboard')
  }, [user, navigate])

  const onSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await Api.post('/auth/signup', { name, email, password })
      setUser(res.data.user)
      navigate('/dashboard')
    } catch (err) {
      console.error(err)
      setError('Signup failed. Try another email.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-md mx-auto mt-10 bg-slate-900/60 border border-slate-700 rounded-2xl p-6">
      <h2 className="text-xl font-semibold mb-4">Create account</h2>
      <form onSubmit={onSubmit} className="space-y-4 text-sm">
        <div>
          <label className="block mb-1 text-slate-300">Name</label>
          <input
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"
            value={name}
            onChange={e => setName(e.target.value)}
          />
        </div>
        <div>
          <label className="block mb-1 text-slate-300">Email</label>
          <input
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />
        </div>
        <div>
          <label className="block mb-1 text-slate-300">Password</label>
          <input
            type="password"
            className="w-full rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 text-sm"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="text-xs text-red-400">{error}</p>}
        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-sm font-semibold"
        >
          {loading ? 'Creating…' : 'Sign up'}
        </button>
      </form>
    </div>
  )
}

function Dashboard() {
  const { stories, setStories } = useApp()
  const navigate = useNavigate()
  const [idea, setIdea] = useState('A tired nurse discovers something impossible on the night shift.')
  const [genre, setGenre] = useState('Thriller')
  const [length, setLength] = useState('Short (5–7 scenes)')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const generateStory = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      const res = await Api.post('/ai/generate-story', { idea, genre, length })
      const story = res.data.story
      const id = `story-${Date.now()}`
      const normalized = {
        id,
        title: story.title,
        genre: story.genre,
        length: story.length,
        scenes: story.scenes || [],
        world: null,
        cost: null,
        screenplay: ''
      }
      setStories(prev => [normalized, ...prev])
      navigate(`/story/${id}`)
    } catch (err) {
      console.error(err)
      setError('Failed to generate story. Check your Mistral API key and try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <section className="grid md:grid-cols-[1.2fr,1fr] gap-6 items-start">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <h2 className="text-lg font-semibold mb-2">New story</h2>
          <p className="text-xs text-slate-400 mb-3">
            Describe your idea and let Mistral create a scene-by-scene draft.
          </p>
          <form onSubmit={generateStory} className="space-y-3 text-sm">
            <div>
              <label className="block mb-1 text-slate-300">Idea / logline</label>
              <textarea
                rows={3}
                className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                value={idea}
                onChange={e => setIdea(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block mb-1 text-slate-300">Genre</label>
                <input
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                  value={genre}
                  onChange={e => setGenre(e.target.value)}
                />
              </div>
              <div>
                <label className="block mb-1 text-slate-300">Length</label>
                <select
                  className="w-full rounded-lg bg-slate-950 border border-slate-800 px-3 py-2 text-sm"
                  value={length}
                  onChange={e => setLength(e.target.value)}
                >
                  <option>Short (5–7 scenes)</option>
                  <option>Medium (8–12 scenes)</option>
                  <option>Feature (13–20 scenes)</option>
                </select>
              </div>
            </div>
            {error && <p className="text-xs text-red-400">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="mt-1 px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-sm font-semibold"
            >
              {loading ? 'Calling Mistral…' : '✨ Generate with Mistral'}
            </button>
          </form>
        </div>
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <h2 className="text-lg font-semibold mb-2">Quick tips</h2>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside">
            <li>Be specific about tone, e.g., “slow-burn psychological thriller with minimal dialogue”.</li>
            <li>Mention key constraints like single location or small cast.</li>
            <li>You can regenerate or manually edit scenes later.</li>
          </ul>
        </div>
      </section>

      <section>
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-semibold">Your stories</h2>
          <span className="text-xs text-slate-400">{stories.length} total</span>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          {stories.map(story => (
            <button
              key={story.id}
              onClick={() => navigate(`/story/${story.id}`)}
              className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 text-left hover:border-indigo-400 transition"
            >
              <div className="text-sm font-semibold mb-1">{story.title}</div>
              <div className="text-xs text-slate-400 mb-2">
                {story.genre} • {story.length}
              </div>
              <div className="text-xs text-slate-500">
                {story.scenes.length} scenes • World: {story.world ? '✔' : '—'} • Screenplay:{' '}
                {story.screenplay ? '✔' : '—'}
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}

function StoryEditor() {
  const { id } = useParams()
  const { stories, setStories } = useApp()
  const story = stories.find(s => s.id === id) || stories[0]
  const [sceneIndex, setSceneIndex] = useState(0)
  const [localText, setLocalText] = useState(story.scenes[0]?.text || '')
  const [enhanceMode, setEnhanceMode] = useState('Tighten pacing and suspense')
  const [intensity, setIntensity] = useState(70)
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const current = story.scenes[sceneIndex]
    setLocalText(current?.text || '')
    setNotes('')
  }, [sceneIndex, story])

  const saveLocal = () => {
    const updated = { ...story }
    updated.scenes = updated.scenes.map((s, idx) =>
      idx === sceneIndex ? { ...s, text: localText } : s
    )
    setStories(prev => prev.map(s => (s.id === story.id ? updated : s)))
  }

  const enhance = async () => {
    setLoading(true)
    try {
      const res = await Api.post('/ai/enhance-scene', {
        text: localText,
        mode: enhanceMode,
        intensity
      })
      setLocalText(res.data.text || localText)
      setNotes(res.data.notes || 'Enhanced.')
    } catch (err) {
      console.error(err)
      setNotes('Enhancement failed. Check your Mistral API key.')
    } finally {
      setLoading(false)
    }
  }

  const scene = story.scenes[sceneIndex]

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">{story.title}</h1>
          <p className="text-xs text-slate-400">
            Scene {sceneIndex + 1} of {story.scenes.length} – {scene?.title}
          </p>
        </div>
        <div className="flex gap-2 text-xs">
          <button
            disabled={sceneIndex === 0}
            onClick={() => setSceneIndex(i => Math.max(0, i - 1))}
            className="px-3 py-1 rounded-full bg-slate-900 border border-slate-700 disabled:opacity-40"
          >
            ◀ Prev
          </button>
          <button
            disabled={sceneIndex === story.scenes.length - 1}
            onClick={() => setSceneIndex(i => Math.min(story.scenes.length - 1, i + 1))}
            className="px-3 py-1 rounded-full bg-slate-900 border border-slate-700 disabled:opacity-40"
          >
            Next ▶
          </button>
          <button
            onClick={saveLocal}
            className="px-3 py-1 rounded-full bg-indigo-500 hover:bg-indigo-400 font-semibold"
          >
            Save scene
          </button>
        </div>
      </div>

      <div className="grid md:grid-cols-[1.5fr,1fr] gap-4 text-sm">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
          <textarea
            rows={18}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm leading-relaxed"
            value={localText}
            onChange={e => setLocalText(e.target.value)}
          />
        </div>
        <div className="space-y-3">
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
            <h3 className="text-sm font-semibold mb-2">Mistral enhancement</h3>
            <label className="block mb-1 text-xs text-slate-300">Mode</label>
            <select
              className="w-full mb-2 rounded-lg bg-slate-950 border border-slate-800 px-2 py-1 text-xs"
              value={enhanceMode}
              onChange={e => setEnhanceMode(e.target.value)}
            >
              <option>Tighten pacing and suspense</option>
              <option>Deepen character emotions</option>
              <option>Make it more visual and cinematic</option>
              <option>Simplify language and clarify</option>
            </select>
            <label className="block mb-1 text-xs text-slate-300">
              Intensity ({intensity})
            </label>
            <input
              type="range"
              min="10"
              max="100"
              value={intensity}
              onChange={e => setIntensity(Number(e.target.value))}
              className="w-full"
            />
            <button
              onClick={enhance}
              disabled={loading}
              className="mt-2 w-full py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
            >
              {loading ? 'Enhancing with Mistral…' : '✨ Enhance scene'}
            </button>
            {notes && <p className="mt-2 text-xs text-slate-300">{notes}</p>}
          </div>
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
            <h3 className="text-sm font-semibold mb-2">Scene meta</h3>
            <p className="text-xs text-slate-400 mb-1">
              Location: <span className="text-slate-200">{scene?.location}</span>
            </p>
            <p className="text-xs text-slate-400 mb-1">
              Characters: <span className="text-slate-200">{scene?.characters?.join(', ')}</span>
            </p>
            <p className="text-xs text-slate-400">
              Mood: <span className="text-slate-200">{scene?.mood}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function WorldBuilder() {
  const { stories, setStories } = useApp()
  const story = stories[0]
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const extract = async () => {
    setLoading(true)
    setError('')
    try {
      const res = await Api.post('/ai/world', {
        scenes: story.scenes.map(s => ({ text: s.text }))
      })
      const updated = { ...story, world: res.data }
      setStories(prev => prev.map(s => (s.id === story.id ? updated : s)))
    } catch (err) {
      console.error(err)
      setError('Failed to extract world.')
    } finally {
      setLoading(false)
    }
  }

  const world = story.world

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">World builder</h1>
          <p className="text-xs text-slate-400">
            Extract characters, locations, and timeline from your story using Mistral.
          </p>
        </div>
        <button
          onClick={extract}
          disabled={loading}
          className="px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
        >
          {loading ? 'Asking Mistral…' : '⛏️ Extract from story'}
        </button>
      </div>
      {error && <p className="text-xs text-red-400">{error}</p>}

      {world ? (
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
            <h3 className="text-sm font-semibold mb-2">Characters</h3>
            <ul className="space-y-2 text-xs">
              {world.characters?.map((c, idx) => (
                <li key={idx} className="border border-slate-800 rounded-xl p-2">
                  <div className="font-semibold">{c.name}</div>
                  <div className="text-slate-400">{c.role}</div>
                  <div className="text-slate-300 mt-1">{c.description}</div>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
            <h3 className="text-sm font-semibold mb-2">Locations</h3>
            <ul className="space-y-2 text-xs">
              {world.locations?.map((l, idx) => (
                <li key={idx} className="border border-slate-800 rounded-xl p-2">
                  <div className="font-semibold">{l.name}</div>
                  <div className="text-slate-300 mt-1">{l.description}</div>
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3">
            <h3 className="text-sm font-semibold mb-2">Timeline</h3>
            <ul className="space-y-2 text-xs">
              {world.timeline?.map((t, idx) => (
                <li key={idx} className="border border-slate-800 rounded-xl p-2">
                  <div className="font-semibold mb-1">{t.label}</div>
                  <ul className="list-disc list-inside space-y-1">
                    {t.events?.map((ev, i) => (
                      <li key={i}>{ev}</li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : (
        <p className="text-xs text-slate-400">
          No world extracted yet. Click “Extract from story” to let Mistral analyze your scenes.
        </p>
      )}
    </div>
  )
}

function CostCalculator() {
  const { stories } = useApp()
  const story = stories[0]
  const sceneCount = story.scenes.length || 1
  const perScene = 2000
  const cast = 3000
  const location = 1500
  const vfx = story.genre.toLowerCase().includes('sci') ? 4000 : 1000
  const total = sceneCount * perScene + cast + location + vfx

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Production cost sandbox</h1>
      <p className="text-xs text-slate-400 mb-2">
        This is a simple, local-only calculator to get a feeling for how expensive your story might be to shoot.
      </p>
      <div className="grid md:grid-cols-3 gap-4 text-sm">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 col-span-2">
          <h3 className="text-sm font-semibold mb-2">Story summary</h3>
          <p className="text-xs text-slate-300 mb-1">
            Title: <span className="text-slate-50">{story.title}</span>
          </p>
          <p className="text-xs text-slate-300 mb-1">
            Genre: <span className="text-slate-50">{story.genre}</span>
          </p>
          <p className="text-xs text-slate-300 mb-1">
            Scenes: <span className="text-slate-50">{sceneCount}</span>
          </p>
          <p className="text-xs text-slate-400 mt-3">
            Rule of thumb: more scenes, locations, and VFX-heavy sequences will push your budget up.
          </p>
        </div>
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-2">Estimated cost</h3>
          <div className="text-2xl font-bold mb-2">
            ${total.toLocaleString()}
          </div>
          <ul className="text-xs text-slate-300 space-y-1">
            <li>Scenes: ${ (sceneCount * perScene).toLocaleString() }</li>
            <li>Cast: ${ cast.toLocaleString() }</li>
            <li>Locations: ${ location.toLocaleString() }</li>
            <li>VFX: ${ vfx.toLocaleString() }</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

function ScreenplayPage() {
  const { stories, setStories } = useApp()
  const story = stories[0]
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const generate = async () => {
    setLoading(true)
    setError('')
    try {
      const text = story.scenes.map(s => `${s.title}\n${s.text}`).join('\n\n')
      const res = await Api.post('/ai/screenplay', { text })
      const updated = { ...story, screenplay: res.data.screenplay }
      setStories(prev => prev.map(s => (s.id === story.id ? updated : s)))
    } catch (err) {
      console.error(err)
      setError('Failed to generate screenplay.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Screenplay draft</h1>
          <p className="text-xs text-slate-400">
            Convert your current story into a screenplay-style draft using Mistral.
          </p>
        </div>
        <button
          onClick={generate}
          disabled={loading}
          className="px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
        >
          {loading ? 'Calling Mistral…' : '🎬 Generate screenplay'}
        </button>
      </div>
      {error && <p className="text-xs text-red-400">{error}</p>}
      <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-3 text-xs font-mono whitespace-pre-wrap max-h-[28rem] overflow-auto">
        {story.screenplay || 'No screenplay generated yet. Click the button above to create one.'}
      </div>
    </div>
  )
}

function DownloadPage() {
  const { stories } = useApp()
  const story = stories[0]

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(story, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${story.title.replace(/[^a-z0-9]+/gi, '_') || 'story'}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const downloadTxt = () => {
    const text = story.scenes.map((s, i) => `SCENE ${i + 1}: ${s.title}\n${s.text}`).join('\n\n')
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${story.title.replace(/[^a-z0-9]+/gi, '_') || 'story'}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Download & export</h1>
      <p className="text-xs text-slate-400 mb-2">
        Export your story as JSON for further tooling or as plain text for quick sharing.
      </p>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 text-sm">
          <h3 className="text-sm font-semibold mb-2">Story JSON</h3>
          <p className="text-xs text-slate-300 mb-3">
            Includes scenes, any extracted world-building, and screenplay text if available.
          </p>
          <button
            onClick={downloadJson}
            className="px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
          >
            Download .json
          </button>
        </div>
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 text-sm">
          <h3 className="text-sm font-semibold mb-2">Plain text</h3>
          <p className="text-xs text-slate-300 mb-3">
            Simple combined text of all scenes in reading order.
          </p>
          <button
            onClick={downloadTxt}
            className="px-4 py-2 rounded-lg bg-indigo-500 hover:bg-indigo-400 text-xs font-semibold"
          >
            Download .txt
          </button>
        </div>
      </div>
    </div>
  )
}

function SettingsPage() {
  const { user } = useApp()
  const [creativity, setCreativity] = useState(70)
  const [helpFreq, setHelpFreq] = useState(60)

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Settings</h1>
      <div className="grid md:grid-cols-2 gap-4 text-sm">
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-2">Profile</h3>
          <p className="text-xs text-slate-300 mb-1">Name: {user?.name}</p>
          <p className="text-xs text-slate-300 mb-1">Email: {user?.email}</p>
          <p className="text-xs text-slate-400 mt-2">
            This demo does not connect to any real database. Your profile only lives in this browser.
          </p>
        </div>
        <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-2">AI behaviour knobs</h3>
          <label className="block mb-1 text-xs text-slate-300">
            Creativity ({creativity})
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={creativity}
            onChange={e => setCreativity(Number(e.target.value))}
            className="w-full mb-3"
          />
          <label className="block mb-1 text-xs text-slate-300">
            How often to suggest AI help ({helpFreq})
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={helpFreq}
            onChange={e => setHelpFreq(Number(e.target.value))}
            className="w-full mb-2"
          />
          <p className="text-xs text-slate-400">
            These sliders are for UX only in this demo, but in a real app they would map to Mistral parameters
            like temperature and number of suggestions.
          </p>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Routes>
        <Route
          path="/"
          element={
            <Layout>
              <Landing />
            </Layout>
          }
        />
        <Route
          path="/login"
          element={
            <Layout>
              <Login />
            </Layout>
          }
        />
        <Route
          path="/signup"
          element={
            <Layout>
              <Signup />
            </Layout>
          }
        />
        <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Layout>
                <Dashboard />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/story/:id"
          element={
            <PrivateRoute>
              <Layout>
                <StoryEditor />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/world"
          element={
            <PrivateRoute>
              <Layout>
                <WorldBuilder />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/cost"
          element={
            <PrivateRoute>
              <Layout>
                <CostCalculator />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/screenplay"
          element={
            <PrivateRoute>
              <Layout>
                <ScreenplayPage />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/download"
          element={
            <PrivateRoute>
              <Layout>
                <DownloadPage />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <PrivateRoute>
              <Layout>
                <SettingsPage />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="*"
          element={
            <Layout>
              <Navigate to="/" replace />
            </Layout>
          }
        />
      </Routes>
    </AppProvider>
  )
}
