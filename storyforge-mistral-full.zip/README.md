# StoryForge Pro – Mistral Edition

This is a full-stack demo of an AI-assisted storytelling tool powered by **Mistral**.

- Backend: Node + Express, calling the Mistral Chat Completions API.
- Frontend: React + Vite + Tailwind, with a dark, cinematic UI.
- Features: story generation, scene-level enhancement, world-building extraction, simple cost sandbox,
  screenplay conversion, and JSON / TXT export.

## 1. Prerequisites

- Node.js 18+
- A Mistral API key from the Mistral console

## 2. Backend setup

```bash
cd backend
cp .env.example .env
# Edit .env and set:
# MISTRAL_API_KEY=sk-...
# (Optional) MISTRAL_MODEL=mistral-small-latest

npm install
npm run dev   # or: npm start
```

By default the backend listens on **http://localhost:5001**.

You can test it:

```bash
curl http://localhost:5001/api/health
```

You should see a small JSON response.

## 3. Frontend setup

```bash
cd frontend
npm install
npm run dev
```

The UI will be available on **http://localhost:5173**.

The Vite dev server is configured to proxy `/api` to `http://localhost:5001`.

## 4. Main flows

### 4.1 Auth

This demo uses an in-memory user store on the backend and keeps the authenticated user in browser
localStorage. It is **not** production auth, just enough for the experience.

1. Go to `/signup`, create an account.
2. You will be redirected to the dashboard.

### 4.2 Generate a story

On the **Dashboard**:

1. Enter an idea / logline, for example:

   > A tired nurse discovers something impossible on the night shift.

2. Choose a genre and length.
3. Click **"✨ Generate with Mistral"**.

The backend calls `/api/ai/generate-story`, which in turn calls Mistral and tries to parse a JSON story
object with scenes. The new story appears in **Your stories** and opens in the Story Editor.

### 4.3 Edit and enhance scenes

On the **Story Editor** page:

- Navigate between scenes (Prev / Next).
- Edit the text in the big editor area.
- Pick an enhancement mode and intensity.
- Click **"✨ Enhance scene"**.

The app calls `/api/ai/enhance-scene` and replaces the scene text with Mistral's edited version.
A short explanation of the changes is shown on the side.

### 4.4 World Builder

On the **World** page:

- Click **"⛏️ Extract from story"**.

The app sends all scenes to `/api/ai/world`, which asks Mistral to extract structured characters,
locations, and a simple timeline. The result is stored on the story and displayed in three columns.

### 4.5 Cost sandbox

On the **Cost** page:

- A simple rule-of-thumb cost estimate is computed locally based on scene count and genre. This does
  not call the API, but it shows how a real budgeting tool could be wired.

### 4.6 Screenplay

On the **Screenplay** page:

- Click **"🎬 Generate screenplay"** to call `/api/ai/screenplay`.
- The backend sends the combined story text to Mistral with instructions to output screenplay-style text.
- The resulting screenplay is stored on the story and shown in a monospace block.

### 4.7 Download / export

On the **Download** page:

- **Download .json** – exports the entire story object (including world + screenplay if present).
- **Download .txt** – exports a simple concatenation of all scenes.

Both exports are generated fully on the client and do not call the backend.

## 5. Notes

- This project is **for local demo / learning**. There is no user database, no security hardening, and
  no persistence on the backend.
- All AI calls go directly to the Mistral API using your API key; be mindful of usage and cost.
- To adapt the prompts, edit `backend/src/index.js` where each `/api/ai/*` endpoint calls `callMistral`.

Enjoy experimenting with StoryForge Pro – Mistral Edition 🚀
