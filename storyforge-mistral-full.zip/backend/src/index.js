import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import fetch from 'node-fetch';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5001;
const MISTRAL_API_KEY = process.env.MISTRAL_API_KEY || '';
const MISTRAL_MODEL = process.env.MISTRAL_MODEL || 'mistral-small-latest';

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

function ensureApiKey(req, res) {
  if (!MISTRAL_API_KEY) {
    res.status(500).json({ error: 'MISTRAL_API_KEY is not set. Please configure your .env.' });
    return false;
  }
  return true;
}

async function callMistral(messages, options = {}) {
  if (!MISTRAL_API_KEY) {
    throw new Error('MISTRAL_API_KEY is not set');
  }
  const body = {
    model: MISTRAL_MODEL,
    messages,
    temperature: options.temperature ?? 0.7,
    max_tokens: options.max_tokens ?? 1024,
  };
  const response = await fetch('https://api.mistral.ai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': `Bearer ${MISTRAL_API_KEY}`,
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Mistral API error: ${response.status} ${text}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content ?? '';
  return content;
}

// Simple in-memory users (for demo only)
const users = [];

// Auth routes
app.post('/api/auth/signup', (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Missing fields' });
  }
  const existing = users.find(u => u.email === email);
  if (existing) {
    return res.status(400).json({ error: 'User already exists' });
  }
  const user = { id: users.length + 1, name, email };
  users.push({ ...user, password });
  res.json({ user });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const existing = users.find(u => u.email === email && u.password === password);
  if (!existing) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const { password: _pw, ...user } = existing;
  res.json({ user });
});

// AI: generate story
app.post('/api/ai/generate-story', async (req, res) => {
  if (!ensureApiKey(req, res)) return;
  const { idea, genre, length } = req.body;
  try {
    const sys = {
      role: 'system',
      content: 'You are an assistant that generates structured JSON stories. Always respond with valid JSON only.'
    };
    const user = {
      role: 'user',
      content: `Generate a story based on this idea:

Idea: ${idea || 'A mysterious night shift in a hospital.'}
Genre: ${genre || 'Thriller'}
Length: ${length || 'Short (5–7 scenes)'}

Return ONLY JSON in this format:
{
  "title": "string",
  "genre": "string",
  "length": "string",
  "scenes": [
    {
      "id": 1,
      "title": "string",
      "location": "string",
      "characters": ["string"],
      "mood": "string",
      "text": "full scene text"
    }
  ]
}`
    };

    const raw = await callMistral([sys, user], { max_tokens: 1600 });
    let jsonStart = raw.indexOf('{');
    let jsonEnd = raw.lastIndexOf('}');
    if (jsonStart === -1 || jsonEnd === -1) {
      throw new Error('No JSON found in model output');
    }
    const jsonText = raw.slice(jsonStart, jsonEnd + 1);
    const data = JSON.parse(jsonText);
    res.json({ story: data });
  } catch (err) {
    console.error(err);
    // Minimal fallback story
    return res.status(200).json({
      story: {
        title: idea ? `Story: ${idea.slice(0, 40)}` : 'Untitled Story',
        genre: genre || 'Unknown',
        length: length || 'Short',
        scenes: [
          {
            id: 1,
            title: 'Opening Scene',
            location: 'Unknown location',
            characters: ['Protagonist'],
            mood: 'Neutral',
            text: idea || 'The story begins...'
          }
        ]
      },
      warning: 'Mistral response could not be parsed; using fallback story.'
    });
  }
});

// AI: enhance scene
app.post('/api/ai/enhance-scene', async (req, res) => {
  if (!ensureApiKey(req, res)) return;
  const { text, mode, intensity } = req.body;
  try {
    const sys = {
      role: 'system',
      content: 'You are an expert story editor. Respond with JSON only.'
    };
    const user = {
      role: 'user',
      content: `Rewrite the following scene.

Mode: ${mode || 'Improve clarity and tension'}
Intensity (0-100): ${intensity ?? 70}

Scene:
${text}

Return ONLY JSON with this structure:
{
  "text": "rewritten scene text",
  "notes": "short explanation of what you changed"
}`
    };
    const raw = await callMistral([sys, user], { max_tokens: 1200 });
    let jsonStart = raw.indexOf('{');
    let jsonEnd = raw.lastIndexOf('}');
    if (jsonStart === -1 || jsonEnd === -1) {
      throw new Error('No JSON found');
    }
    const jsonText = raw.slice(jsonStart, jsonEnd + 1);
    const data = JSON.parse(jsonText);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(200).json({
      text,
      notes: 'Fallback: returning original text because the model response could not be parsed.'
    });
  }
});

// AI: world-building extraction
app.post('/api/ai/world', async (req, res) => {
  if (!ensureApiKey(req, res)) return;
  const { scenes } = req.body;
  const sceneText = (scenes || []).map((s, i) => `Scene ${i + 1}: ${s.text}`).join('\n\n');
  try {
    const sys = {
      role: 'system',
      content: 'You extract structured world-building data from a story. Respond with JSON only.'
    };
    const user = {
      role: 'user',
      content: `From the following story scenes, extract a list of characters, locations, and a simple timeline (ordered events).

${sceneText || 'No scenes provided.'}

Return ONLY JSON like:
{
  "characters": [
    { "name": "string", "role": "short role", "description": "1-2 sentences" }
  ],
  "locations": [
    { "name": "string", "description": "1-2 sentences" }
  ],
  "timeline": [
    { "label": "Day 1", "events": ["string", "string"] }
  ]
}`
    };
    const raw = await callMistral([sys, user], { max_tokens: 1500 });
    let jsonStart = raw.indexOf('{');
    let jsonEnd = raw.lastIndexOf('}');
    if (jsonStart === -1 || jsonEnd === -1) {
      throw new Error('No JSON found');
    }
    const jsonText = raw.slice(jsonStart, jsonEnd + 1);
    const data = JSON.parse(jsonText);
    res.json(data);
  } catch (err) {
    console.error(err);
    // Very basic heuristic fallback
    const fallback = {
      characters: [
        { name: 'Protagonist', role: 'Main character', description: 'Placeholder character extracted in fallback mode.' }
      ],
      locations: [
        { name: 'Unknown', description: 'Fallback location.' }
      ],
      timeline: [
        { label: 'Day 1', events: ['Story events (fallback).'] }
      ]
    };
    res.status(200).json(fallback);
  }
});

// AI: screenplay conversion
app.post('/api/ai/screenplay', async (req, res) => {
  if (!ensureApiKey(req, res)) return;
  const { text } = req.body;
  try {
    const sys = {
      role: 'system',
      content: 'You are a professional screenwriter. Convert prose into screenplay format.'
    };
    const user = {
      role: 'user',
      content: `Convert the following story text into screenplay format (INT/EXT, character names in caps, dialogue, action lines). Keep it concise but cinematic.

Story text:
${text}

Return ONLY the screenplay text (no JSON).`
    };
    const screenplay = await callMistral([sys, user], { max_tokens: 2000 });
    res.json({ screenplay });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to generate screenplay' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', model: MISTRAL_MODEL ? 'configured' : 'not-configured' });
});

app.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
});
